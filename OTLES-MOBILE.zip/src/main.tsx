import {
  StrictMode,
} from "react";

import {
  createRoot,
} from "react-dom/client";

import "./index.css";

import App from "./App";

import {
  AuthProvider,
} from "./contexts/AuthContext";


/* ==========================================================
   APPLICATION ENTRY 001
   ========================================================== */


createRoot(
  document.getElementById("root")!,
).render(

  <StrictMode>

    <AuthProvider>

      <App />

    </AuthProvider>

  </StrictMode>,

);
